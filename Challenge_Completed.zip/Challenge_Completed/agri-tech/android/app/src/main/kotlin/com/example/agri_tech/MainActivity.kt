package com.example.agri_tech

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

// lib/main.dart
import 'package:flutter/material.dart';
// Import the generative_ai package
import 'package:google_generative_ai/google_generative_ai.dart';

// =============================================================================
// IMPORTANT: Add the google_generative_ai dependency to your pubspec.yaml file!
//
// Open your pubspec.yaml file and add the following under 'dependencies:':
//
// dependencies:
//   flutter:
//     sdk: flutter
//   cupertino_icons: ^1.0.2 # Example existing dependency
//   google_generative_ai: ^[actual_latest_version] # <--- REPLACE [actual_latest_version] with the version from pub.dev (e.g., ^0.0.1)
//
// After saving pubspec.yaml, run 'flutter pub get' in your terminal.
// This step is crucial for the package to be recognized.
// =============================================================================

// Note: While consolidating into a single file is possible,
// it's generally better practice to separate screens into different files
// for better organization and maintainability in larger applications.

void main() {
  runApp(const AgriAssistApp());
}

class AgriAssistApp extends StatelessWidget {
  const AgriAssistApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AgriAssist',
      theme: ThemeData(
        primarySwatch: Colors.green,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const HomeScreen(), // Set HomeScreen as the initial screen
    );
  }
}

// HomeScreen widget - Previously in lib/screens/home_screen.dart
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AgriAssist - Farming Advisor'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              // App Title and Description
              const Text(
                'Welcome to AgriAssist!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Your AI-powered farming advisor. Get guidance on farming queries, pest detection, and weather conditions.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 40),

              // Buttons to navigate to different features
              ElevatedButton.icon(
                icon: const Icon(Icons.chat),
                label: const Text('AI Chatbot'),
                onPressed: () {
                  // Navigate to the Chatbot Screen
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ChatbotScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  textStyle: const TextStyle(fontSize: 18),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                icon: const Icon(Icons.bug_report),
                label: const Text('Pest & Disease Detection'),
                onPressed: () {
                  // Navigate to the Pest Detection Screen
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const PestDetectionScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  textStyle: const TextStyle(fontSize: 18),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                icon: const Icon(Icons.cloud),
                label: const Text('Weather & Soil Tips'),
                onPressed: () {
                  // Navigate to the Weather Screen
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const WeatherScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  textStyle: const TextStyle(fontSize: 18),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ChatbotScreen widget - Previously in lib/screens/chatbot_screen.dart
class ChatbotScreen extends StatefulWidget {
  const ChatbotScreen({super.key});

  @override
  _ChatbotScreenState createState() => _ChatbotScreenState();
}

class _ChatbotScreenState extends State<ChatbotScreen> {
  final TextEditingController _messageController = TextEditingController();
  final List<String> _messages = []; // Placeholder for chat messages

  // Initialize the Gemini model
  // IMPORTANT: Replace 'YOUR_API_KEY' with your actual API key.
  // Storing API keys directly in code is not recommended for production apps.
  // Consider using environment variables or a secure method.
  final String _apiKey =
      'AIzaSyBQnlDvJmlf4i3gwvwJqIhZZchxO2GxiqI'; // Your provided API key
  late final GenerativeModel _model;

  @override
  void initState() {
    super.initState();
    // Initialize the model with the API key and the desired model name (e.g., 'gemini-pro')
    _model = GenerativeModel(model: 'gemini-pro', apiKey: _apiKey);
  }

  void _sendMessage() async {
    // Made the function async
    if (_messageController.text.isNotEmpty) {
      final userMessage = _messageController.text;
      // Add the user's message to the list
      setState(() {
        _messages.add("You: $userMessage");
      });

      // Clear the input field immediately
      _messageController.clear();

      try {
        // Create content for the API request
        final content = [Content.text(userMessage)];

        // Call the Gemini API to generate a response
        final response = await _model.generateContent(content);

        // Add the Gemini's response to the list
        setState(() {
          // Handle potential null response or text content
          final geminiResponse =
              response.text ?? 'Error: No response text from Gemini.';
          _messages.add("AgriAssist: $geminiResponse");
        });
      } catch (e) {
        // Handle any errors during the API call
        setState(() {
          _messages.add("AgriAssist: Error communicating with AI: $e");
        });
        print(
            'Error calling Gemini API: $e'); // Print error to console for debugging
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Chatbot'),
      ),
      body: Column(
        children: <Widget>[
          // Chat messages display area
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(8.0),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(_messages[index]),
                );
              },
            ),
          ),
          // Message input area
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: const InputDecoration(
                      hintText: 'Ask a farming question...',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (_) =>
                        _sendMessage(), // Send message on pressing Enter
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// PestDetectionScreen widget - Previously in lib/screens/pest_detection_screen.dart
class PestDetectionScreen extends StatefulWidget {
  const PestDetectionScreen({super.key});

  @override
  _PestDetectionScreenState createState() => _PestDetectionScreenState();
}

class _PestDetectionScreenState extends State<PestDetectionScreen> {
  // File? _image; // Variable to hold the selected image

  // Future<void> _pickImage() async {
  //   final picker = ImagePicker();
  //   final pickedFile = await picker.pickImage(source: ImageSource.gallery); // Or ImageSource.camera
  //
  //   if (pickedFile != null) {
  //     setState(() {
  //       _image = File(pickedFile.path);
  //     });
  //     // TODO: Send the image to Gemini Vision API for analysis
  //     // Display the results
  //   } else {
  //     print('No image selected.');
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pest & Disease Detection'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              // Display selected image (if any)
              // _image == null
              //     ? const Text('No image selected.')
              //     : Image.file(_image!),
              const Text(
                  'Upload an image of a plant to detect pests or diseases.'),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                icon: const Icon(Icons.camera_alt),
                label: const Text('Pick Image'),
                onPressed: () {
                  // TODO: Implement image picking logic
                  // _pickImage();
                  print('Image picking not yet implemented.');
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  textStyle: const TextStyle(fontSize: 18),
                ),
              ),
              const SizedBox(height: 20),
              // TODO: Display detection results here
              const Text(
                  'Detection results will appear here after uploading an image.'),
            ],
          ),
        ),
      ),
    );
  }
}

// WeatherScreen widget - Previously in lib/screens/weather_screen.dart
class WeatherScreen extends StatefulWidget {
  const WeatherScreen({super.key});

  @override
  _WeatherScreenState createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  // Placeholder for weather data
  String weatherData = "Fetching weather data...";

  @override
  void initState() {
    super.initState();
    // TODO: Fetch weather data using OpenWeatherMap API
    // Update the weatherData variable
    _fetchWeatherData();
  }

  void _fetchWeatherData() {
    // Simulate fetching data
    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        weatherData = "Current Weather: Sunny, 25°C\nSoil Moisture: Optimal";
        // In a real app, this would be data from OpenWeatherMap and potentially soil sensors
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Weather & Soil Tips'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Icon(Icons.cloud_queue, size: 80, color: Colors.blue),
              const SizedBox(height: 20),
              const Text(
                'Local Weather and Soil Conditions',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              // Display weather data
              Text(
                weatherData,
                style: const TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              // TODO: Add more detailed tips based on weather and soil data (using Gemini)
              const Text(
                'Tips for today based on conditions:',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              const Text(
                'Placeholder for Gemini-generated tips based on weather and soil data.',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
